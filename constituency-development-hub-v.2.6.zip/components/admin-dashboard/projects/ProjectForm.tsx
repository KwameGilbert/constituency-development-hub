"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RichTextEditor } from "@/components/ui/rich-text-editor";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Save, Upload, X, ChevronsUpDown, Check } from "lucide-react";
import { toast } from "sonner";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { cn } from "@/lib/utils";
import {
  projectsService,
  CreateProjectData,
  Project,
} from "@/lib/services/projects-service";
import { 
  sectorsService, 
  Sector 
} from "@/lib/services/sectors-service";
import { 
  locationsService, 
  Location 
} from "@/lib/services/locations-service";
import { uploadService } from "@/lib/services/upload-service";
import { Checkbox } from "@/components/ui/checkbox";
import Image from "next/image";

const projectSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  sector_id: z.string().min(1, "Please select a sector"),
  location: z.string().min(3, "Location is required"),
  status: z.enum(["planning", "ongoing", "completed", "on_hold"]),
  start_date: z.string().min(1, "Start date is required"),
  end_date: z.string().min(1, "End date is required"),
  budget: z.string().min(1, "Budget is required"),
  contractor: z.string().optional(),
  contact_person: z.string().optional(),
  contact_phone: z.string().optional(),
  is_featured: z.boolean().optional(),
  progress_percent: z.string().optional(),
  spent: z.string().optional(),
});

type ProjectFormValues = z.infer<typeof projectSchema>;

interface ProjectFormProps {
  project?: Project;
}

export function NewProjectForm({ project }: ProjectFormProps) {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(
    project?.image || null,
  );
  const [sectors, setSectors] = useState<Sector[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [sectorOpen, setSectorOpen] = useState(false);
  const [locationOpen, setLocationOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoadingData(true);
      try {
        const [sectorsResponse, locationsResponse] = await Promise.all([
          sectorsService.getSectors(),
          locationsService.getLocations({ limit: 100 }), // Adjust limit as needed
        ]);

        if (sectorsResponse.success) {
          setSectors(sectorsResponse.data.sectors);
        }

        if (locationsResponse.success) {
          setLocations(locationsResponse.data.locations);
        }
      } catch (error) {
        console.error("Failed to fetch form data:", error);
        toast.error("Failed to load sectors and locations");
      } finally {
        setIsLoadingData(false);
      }
    };

    fetchData();
  }, []);

  const isEditMode = !!project;

  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      title: project?.title || "",
      description: project?.description || "",
      sector_id: project?.sector?.id.toString() || "",
      location: project?.location || "",
      status: project?.status || "planning",
      start_date: project?.start_date || "",
      end_date: project?.end_date || "",
      budget: project?.budget?.toString() || "",
      contractor: project?.contractor || "",
      contact_person: project?.contact_person || "",
      contact_phone: project?.contact_phone || "",
      is_featured: project?.is_featured || false,
      progress_percent: project?.progress_percent?.toString() || "",
      spent: project?.spent?.toString() || "",
    },
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
  };

  async function onSubmit(data: ProjectFormValues) {
    setIsSubmitting(true);

    try {
      let imageUrl = project?.image; // Default to existing URL if editing

      // 1. Upload Image (if new one selected)
      if (selectedImage) {
        try {
          const uploadResponse = await uploadService.uploadFile(
            selectedImage,
            "projects",
          );
          imageUrl = uploadResponse.data.url;
        } catch (uploadError: any) {
          throw new Error("Failed to upload image: " + uploadError.message);
        }
      }

      const projectData: CreateProjectData | any = {
        title: data.title,
        description: data.description,
        sector_id: parseInt(data.sector_id),
        location: data.location,
        status: data.status,
        start_date: data.start_date,
        end_date: data.end_date,
        budget: parseFloat(data.budget),
        contractor: data.contractor || undefined,
        contact_person: data.contact_person || undefined,
        contact_phone: data.contact_phone || undefined,
        is_featured: data.is_featured || false,
        image: imageUrl, // Attach the image URL
      };

      // Add update-specific fields if editing
      if (isEditMode) {
        if (data.progress_percent) {
          projectData.progress_percent = parseInt(data.progress_percent);
        }
        if (data.spent) {
          projectData.spent = parseFloat(data.spent);
        }
      }

      let response;
      if (isEditMode && project) {
        response = await projectsService.updateProject(project.id, projectData);
      } else {
        response = await projectsService.createProject(projectData);
      }

      if (response.success) {
        toast.success(
          isEditMode
            ? "Project updated successfully"
            : "Project created successfully",
        );
        router.push("/admin-dashboard/projects");
        router.refresh();
      } else {
        toast.error(
          response.message ||
            `Failed to ${isEditMode ? "update" : "create"} project`,
        );
      }
    } catch (error: any) {
      console.error(
        `Error ${isEditMode ? "updating" : "creating"} project:`,
        error,
      );
      toast.error(
        error.message ||
          `An error occurred while ${isEditMode ? "updating" : "creating"} the project`,
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <Card>
        <CardContent className="pt-6 space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">
              Basic Information
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="title">Project Title *</Label>
                <Input
                  id="title"
                  placeholder="e.g., Road Rehabilitation Project"
                  {...form.register("title")}
                  disabled={isSubmitting}
                />
                {form.formState.errors.title && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.title.message}
                  </p>
                )}
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="description">Description *</Label>
                <RichTextEditor
                  value={form.watch("description")}
                  onChange={(content) => form.setValue("description", content)}
                  disabled={isSubmitting}
                  error={!!form.formState.errors.description}
                  placeholder="Detailed description of the project..."
                  height={200}
                />
                {form.formState.errors.description && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.description.message}
                  </p>
                )}
              </div>

              {/* Image Upload */}
              <div className="md:col-span-2">
                <Label>Project Image</Label>
                <div className="mt-2 flex items-center gap-4">
                  {imagePreview ? (
                    <div className="relative h-32 w-48 overflow-hidden rounded-lg border border-slate-200">
                      <Image
                        src={imagePreview}
                        alt="Preview"
                        fill
                        className="object-cover"
                        unoptimized
                      />
                      <button
                        type="button"
                        onClick={removeImage}
                        className="absolute right-1 top-1 rounded-full bg-red-500 p-1 text-white hover:bg-red-600 focus:outline-none"
                        title="Remove image"
                        disabled={isSubmitting}
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ) : (
                    <div className="flex h-32 w-48 items-center justify-center rounded-lg border border-dashed border-slate-300 bg-slate-50 text-slate-400">
                      <span className="text-sm">No Image</span>
                    </div>
                  )}

                  <div className="flex-1">
                    <Input
                      id="image"
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      disabled={isSubmitting}
                      className="max-w-xs"
                    />
                    <p className="mt-1 text-xs text-slate-500">
                      Supported formats: JPG, PNG, WEBP. Max size: 2MB.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="sector_id">Sector *</Label>
                <Popover open={sectorOpen} onOpenChange={setSectorOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={sectorOpen}
                      className="w-full justify-between font-normal"
                      disabled={isSubmitting || isLoadingData}
                    >
                      {form.watch("sector_id")
                        ? sectors.find(
                            (s) => s.id.toString() === form.watch("sector_id")
                          )?.name || "Select sector"
                        : isLoadingData
                        ? "Loading sectors..."
                        : "Select sector"}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search sectors..." />
                      <CommandList>
                        <CommandEmpty>No sector found.</CommandEmpty>
                        <CommandGroup>
                          {sectors.map((sector) => (
                            <CommandItem
                              key={sector.id}
                              value={sector.name}
                              onSelect={() => {
                                form.setValue("sector_id", sector.id.toString());
                                setSectorOpen(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  form.watch("sector_id") === sector.id.toString()
                                    ? "opacity-100"
                                    : "opacity-0"
                                )}
                              />
                              {sector.name}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                {form.formState.errors.sector_id && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.sector_id.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="location">Location *</Label>
                <Popover open={locationOpen} onOpenChange={setLocationOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={locationOpen}
                      className="w-full justify-between font-normal"
                      disabled={isSubmitting || isLoadingData}
                    >
                      {form.watch("location")
                        ? form.watch("location")
                        : isLoadingData
                        ? "Loading locations..."
                        : "Select location"}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search locations..." />
                      <CommandList>
                        <CommandEmpty>No location found.</CommandEmpty>
                        <CommandGroup>
                          {locations.map((location) => (
                            <CommandItem
                              key={location.id}
                              value={location.name}
                              onSelect={() => {
                                form.setValue("location", location.name);
                                setLocationOpen(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  form.watch("location") === location.name
                                    ? "opacity-100"
                                    : "opacity-0"
                                )}
                              />
                              {location.name}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                {form.formState.errors.location && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.location.message}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Status and Progress */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">
              Status & Progress
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="status">Status *</Label>
                <Select
                  onValueChange={(value: any) => form.setValue("status", value)}
                  defaultValue={form.getValues("status")}
                  disabled={isSubmitting}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="planning">Planning</SelectItem>
                    <SelectItem value="ongoing">Ongoing</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="on_hold">On Hold</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.status && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.status.message}
                  </p>
                )}
              </div>

              {isEditMode && (
                <div>
                  <Label htmlFor="progress_percent">Progress (%)</Label>
                  <Input
                    id="progress_percent"
                    type="number"
                    min="0"
                    max="100"
                    placeholder="0-100"
                    {...form.register("progress_percent")}
                    disabled={isSubmitting}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Financial Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">
              Financial Information
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="budget">Budget (₵) *</Label>
                <Input
                  id="budget"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  {...form.register("budget")}
                  disabled={isSubmitting}
                />
                {form.formState.errors.budget && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.budget.message}
                  </p>
                )}
              </div>

              {isEditMode && (
                <div>
                  <Label htmlFor="spent">Amount Spent (₵)</Label>
                  <Input
                    id="spent"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    {...form.register("spent")}
                    disabled={isSubmitting}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Timeline */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">Timeline</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start_date">Start Date *</Label>
                <Input
                  id="start_date"
                  type="date"
                  {...form.register("start_date")}
                  disabled={isSubmitting}
                />
                {form.formState.errors.start_date && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.start_date.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="end_date">End Date *</Label>
                <Input
                  id="end_date"
                  type="date"
                  {...form.register("end_date")}
                  disabled={isSubmitting}
                />
                {form.formState.errors.end_date && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.end_date.message}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Contractor Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">
              Contractor Information
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="contractor">Contractor Name</Label>
                <Input
                  id="contractor"
                  placeholder="e.g., Ghana Construction Ltd"
                  {...form.register("contractor")}
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="contact_person">Contact Person</Label>
                <Input
                  id="contact_person"
                  placeholder="e.g., John Mensah"
                  {...form.register("contact_person")}
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="contact_phone">Contact Phone</Label>
                <Input
                  id="contact_phone"
                  placeholder="e.g., +233249973054"
                  {...form.register("contact_phone")}
                  disabled={isSubmitting}
                />
              </div>
            </div>
          </div>

          {/* Additional Options */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="is_featured"
                checked={form.watch("is_featured")}
                onCheckedChange={(checked) =>
                  form.setValue("is_featured", checked as boolean)
                }
                disabled={isSubmitting}
              />
              <Label
                htmlFor="is_featured"
                className="text-sm font-normal cursor-pointer"
              >
                Feature this project on the public website
              </Label>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex justify-end gap-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.back()}
          disabled={isSubmitting}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          className="bg-red-600 hover:bg-red-700"
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {isEditMode ? "Updating..." : "Creating..."}
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              {isEditMode ? "Update Project" : "Create Project"}
            </>
          )}
        </Button>
      </div>
    </form>
  );
}
