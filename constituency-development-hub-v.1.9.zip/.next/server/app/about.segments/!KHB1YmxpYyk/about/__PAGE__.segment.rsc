1:"$Sreact.fragment"
2:I[69803,["/_next/static/chunks/347d9dc60c9c861e.js","/_next/static/chunks/ad310614150b908a.js","/_next/static/chunks/170d4a7b368d88c2.js","/_next/static/chunks/f800e625b531194c.js","/_next/static/chunks/bdd41dc448cc692f.js","/_next/static/chunks/e084fd3bcabd127b.js"],"default"]
3:I[85842,["/_next/static/chunks/975ebbd0437533b8.js","/_next/static/chunks/327500805fd2db9e.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"iW09nXv8vWc2Ra_Qtkcvj","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/bdd41dc448cc692f.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/e084fd3bcabd127b.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
