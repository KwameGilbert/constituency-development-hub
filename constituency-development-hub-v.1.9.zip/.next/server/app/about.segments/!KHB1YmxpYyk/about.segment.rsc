1:"$Sreact.fragment"
2:I[1691,["/_next/static/chunks/975ebbd0437533b8.js","/_next/static/chunks/327500805fd2db9e.js"],"default"]
3:I[30482,["/_next/static/chunks/975ebbd0437533b8.js","/_next/static/chunks/327500805fd2db9e.js"],"default"]
0:{"buildId":"iW09nXv8vWc2Ra_Qtkcvj","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
