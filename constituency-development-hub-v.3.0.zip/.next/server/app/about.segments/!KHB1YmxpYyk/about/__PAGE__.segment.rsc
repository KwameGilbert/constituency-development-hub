1:"$Sreact.fragment"
2:I[869803,["/_next/static/chunks/868122fc12bb3008.js","/_next/static/chunks/f2eefddcf25160ae.js","/_next/static/chunks/90a76d45d7881b44.js","/_next/static/chunks/11502a5d9c2f5df7.js","/_next/static/chunks/d77d09779f3f3bea.js","/_next/static/chunks/469be560aceee4bb.js"],"default"]
3:I[585842,["/_next/static/chunks/804f11d7e70c2ea2.js","/_next/static/chunks/d91cd735a3364761.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"K5Qs1Jp-Qy4gxN-omGE0P","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/d77d09779f3f3bea.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/469be560aceee4bb.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
