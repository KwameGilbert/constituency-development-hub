1:"$Sreact.fragment"
2:I[501691,["/_next/static/chunks/804f11d7e70c2ea2.js","/_next/static/chunks/d91cd735a3364761.js"],"default"]
3:I[30482,["/_next/static/chunks/804f11d7e70c2ea2.js","/_next/static/chunks/d91cd735a3364761.js"],"default"]
0:{"buildId":"K5Qs1Jp-Qy4gxN-omGE0P","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
